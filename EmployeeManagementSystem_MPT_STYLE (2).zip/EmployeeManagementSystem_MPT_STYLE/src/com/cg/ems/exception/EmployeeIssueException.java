package com.cg.ems.exception;

public class EmployeeIssueException extends Exception
{
	public EmployeeIssueException(String msg) {
		super(msg);
	}
}
